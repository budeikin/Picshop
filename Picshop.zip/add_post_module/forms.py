from django import forms
from post_module.models import Post, Profession


class AddPostModelForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['name', 'age', 'email', 'image', 'description', 'profession']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'enter your name'
            }),
            'age': forms.NumberInput()
            ,
            'email': forms.EmailInput()
            ,
            'image': forms.FileInput(attrs={
                'class': 'form-control',
                'placeholder': 'profile'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'enter description',
                'rows': 4
            }),
        }

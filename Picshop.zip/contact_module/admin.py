from django.contrib import admin
from contact_module.models import ContactUs
# Register your models here.

admin.site.register(ContactUs)

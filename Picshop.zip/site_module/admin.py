from django.contrib import admin
from .models import SiteSetting
# Register your models here.

admin.site.register(SiteSetting)


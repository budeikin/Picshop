from django.db.models import Count
from django.views.generic import ListView, DetailView
from django.shortcuts import render
from .models import Post, Profession


# Create your views here.


class PersonListView(ListView):
    template_name = 'post_module/list_of_person.html'
    model = Post
    context_object_name = 'posts'
    ordering = ['-id']

    def get_queryset(self):
        query = super(PersonListView, self).get_queryset()
        profession_name = self.kwargs.get('pro')
        if profession_name is not None:
            query = query.filter(profession__title_url__iexact=profession_name)
        return query


class PersonDetailView(DetailView):
    template_name = 'post_module/detail_of_person.html'
    model = Post
    context_object_name = 'post'

    def get_context_data(self, **kwargs):
        context = super(PersonDetailView, self).get_context_data()
        return context


def profession_categories_component(request):
    profession: Profession = Profession.objects.annotate(persons_count=Count('persons')).filter(is_active=True,
                                                                                                persons__gt=0)
    context = {
        'professions': profession
    }
    return render(request, 'post_module/components/profession_categories_component.html', context)
